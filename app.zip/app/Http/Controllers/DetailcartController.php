<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Detailcart;
use App\Models\Price;
use App\Models\Product;
use App\Models\Stock;
use Illuminate\Support\Facades\Auth;
use stdClass;

class DetailcartController extends Controller
{
    //
	public function index(Request $request){
		$data = Detailcart::fetch($request);
		$fieldOnGrid = Detailcart::getFieldOnGrid();
		return view('detailcart.default', compact('data','fieldOnGrid'));
	}
	public function create(){
		$data = new Detailcart;
		$fieldOnForm = Detailcart::getFieldOnForm();
		return view('detailcart.form', compact('data','fieldOnForm'));
    }

	public function store(Request $request){
        $values = $request->except('_token', 'save');
        $stock = Stock::GetStock(new Request(['outlet_id' => Auth()->user()->outlet_id, 'product_id' => $request->product_id]));
        $product = Product::findOrFail($request->product_id);

        if(($stock >= $request->qty) || ($product->is_unlimited == true)){
            $currentData = Detailcart::where('user_id', Auth()->user()->id)->where('product_id', $request->product_id)->get();

            if(count($currentData)){
                $values['qty'] = $currentData->first()->qty + $request->qty;
                $model = $currentData->first();
            }else{
                $values['user_id'] = Auth()->user()->id;
                $values['price'] = Price::where('product_id', $values['product_id'])->first()->price;
                $values['status'] = 1;
                $model = new Detailcart();
            }

            $result = $this->baseStore($request->_method, $model, $values, 'Detailcart');
        }else{
            $message = ['key' => ucwords('order'), 'value' => 'Order'];
            $status = 'error'; $type = 'update';
            $response = trans('message.create_failed', $message);

            $result = ['status' => $status, 'response' => $response];
        }

		return $this->baseRedirect($request, 'order/create',$result);
    }

	public function show($id){
		$data = Detailcart::findOrFail($id);
		$fieldOnForm = Detailcart::getFieldOnForm();
		return view('detailcart.show', compact('data','fieldOnForm'));
	}
	public function edit($id){
		$data = Detailcart::findOrFail($id);
		$fieldOnForm = Detailcart::getFieldOnForm();
		return view('detailcart.form', compact('data','fieldOnForm'));
	}
	public function update(Request $request, $id){
		$values = $request->except('_token', '_method');
		$result = $this->baseStore($request->_method, Detailcart::findOrFail($id), $values, 'Detailcart');
		return $this->baseRedirect($request, 'detailcart.index',$result);
	}
	public function destroy(Request $request, $id){
		$result = $this->baseDestroy(Detailcart::findOrFail($id), true);
		return $this->baseRedirect($request, 'detailcart',$result);
	}
	// public function softdelete($id){
	// 	$result = $this->baseStore(Detailcart::findOrFail($id), ['deleted_at' => Carbon::now()]);
	// 	return $this->baseRedirect(new Request(), 'detailcart', $result);
    // }

    public function emptyByUser(){
        $data = Detailcart::where('user_id', Auth()->user()->id)->delete();
        return response()->json(['data' => $data]);
    }

    public function getCountByUser(){
        $data = Detailcart::where('user_id', Auth()->user()->id)->count();
        return response()->json(['data' => $data]);
    }
}
