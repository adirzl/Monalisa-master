<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Dashboard;
use App\Models\User;
use Carbon\Carbon;

class DashboardController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware(['auth', 'verified']);
    }

    public function index(){//dd(Auth()->user());
        // $data = User::whereNotIn('username',['sa','admin'])->orderBy('name')->get();
        // if(!in_array(auth()->user()->roles->first()->name, ['Super Admin','Admin'])){
        //     $data = $data->where('id', auth()->user()->id);
        // }
        // // $data = User::all();
        // foreach($data as $d){
        //     $d->today = $d->story->where('date_story', Carbon::today()->toDateString())->where('deleted_at','==',null)->count();
        //     $d->yesterday = $d->story->where('date_story', Carbon::yesterday()->toDateString())->where('deleted_at','==',null)->count();
        //     $d->dayMin_3 = $d->story->where('date_story', Carbon::today()->add(-2,'day')->toDateString())->where('deleted_at','==',null)->count();
        // }

        return view('dashboard');
    }
}
