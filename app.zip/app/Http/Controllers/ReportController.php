<?php

namespace App\Http\Controllers;

use App\Exports\StoryExport;
// use App\Facades\Excel;
use App\Facades\PDF as FacadesPDF;
use App\Http\Requests\ExportReport;
use Illuminate\Http\Request;
use App\Models\Report;
use App\Models\Story;
use App\Models\User;
use Knp\Snappy\Pdf;
use Maatwebsite\Excel\Facades\Excel;

class ReportController extends Controller
{
    //
	public function index(Request $request){
        $data = new Report();
        $user = to_dropdown(User::orderBy('name')->get(), 'id', 'name');
        \Assets::addJs('admin\report.js');
		return view('report.default', compact('data', 'user'));
    }

    public function export(ExportReport $request){

        //$this->export_maat();
        dd('tes');
        $filename = 'Story-' . now()->format('YmdHis');

        if ($request->type === 'xls') {
            return (new \Modules\MonitoringNominatifKredit\Exports\MonitoringNominatifKredit($request))
                ->download($filename . '.xls', \Maatwebsite\Excel\Excel::XLS);
        } else {
            if($request->report_type == 1){
                $data = Story::where('user_id', $request->user_id)->get();
                $view = 'report.pdf_peruser';
                $param = User::findOrFail($request->user_id)->name;
            }else{
                $data = Story::where('date_story', $request->story_date)->get();
                $view = 'report.pdf_perdate';
                $param = $request->story_date;
            }

            // $pdf = new Pdf(config('app.snappy_binary'));
            // $html = view($view, compact('data','param'))->render();
            // header('Content-Type: application.pdf');
            // header('Content-Disposition: attachment; filename=' . $filename . '.pdf');
            // echo $pdf->getOutputFromHtml($html, ['orientation' => 'Landscape']);

            $pdf = FacadesPDF::loadView($view, compact('data','param'));
            return $pdf->download($filename);
        }
    }

    public function export_snappy(ExportReport $request){
        $filename = 'Story-' . now()->format('YmdHis');

        if ($request->type === 'xls') {
            return (new \Modules\MonitoringNominatifKredit\Exports\MonitoringNominatifKredit($request))
                ->download($filename . '.xls', \Maatwebsite\Excel\Excel::XLS);
        } else {
            if($request->report_type == 1){
                $data = Story::where('user_id', $request->user_id)->get();
                $view = 'report.pdf_peruser';
                $param = User::findOrFail($request->user_id)->name;
            }else{
                $data = Story::where('date_story', $request->story_date)->get();
                $view = 'report.pdf_perdate';
                $param = $request->story_date;
            }

            $pdf = new Pdf(config('app.snappy_binary'));
            $html = view($view, compact('data','param'))->render();
            header('Content-Type: application.pdf');
            header('Content-Disposition: attachment; filename=' . $filename . '.pdf');
            echo $pdf->getOutputFromHtml($html, ['orientation' => 'Landscape']);
        }
    }

    public function export_maat(ExportReport $request){
        $filename = 'Story-' . now()->format('YmdHis');
        return \Maatwebsite\Excel\Facades\Excel::download(new StoryExport($request), $filename.'.xlsx');
        // return Excel::download(new StoryExport, 'story.xlsx');

        // \Maatwebsite\Excel\Facades\Excel::download();
    }
}
