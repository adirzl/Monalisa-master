<?php

namespace App\Http\Controllers;

use App\Models\Cart;
use App\Models\Customer;
use App\Models\Detailcart;
use App\Models\Detailorder;
use App\Models\Discount;
use Illuminate\Http\Request;
use App\Models\Order;
use App\Models\Product;
use App\Models\Stock;
use App\Models\User;
use Ramsey\Uuid\Uuid;

class OrderController extends Controller
{
    //
	public function index(Request $request){
        $data = Order::fetch($request);
        $fieldOnGrid = Order::getFieldOnGrid();

        $ordertype = to_dropdown(getOptionGroup('order_ordertype'), 'key', 'value');
        $paymenttype = to_dropdown(getOptionGroup('order_paymenttype'), 'key', 'value');
        $user_id = to_dropdown(User::all(), 'id', 'name');

		return view('order.default', compact('data','fieldOnGrid','ordertype','paymenttype', 'user_id'));
	}
	public function create(){
        $data = new Order;
        $dataCart = new Cart;
        $fieldOnForm = Order::getFieldOnForm();

        $ordertype = to_dropdown(getOptionGroup('order_ordertype'), 'key', 'value');
        $paymenttype = to_dropdown(getOptionGroup('order_paymenttype'), 'key', 'value');
        $productList = Product::where('status', 1)->paginate(10);
        $customer_id = to_dropdown(Customer::all(), 'id', 'name');

        $cart = Detailcart::where('status', 1)->where('user_id', Auth()->user()->id)->get();
        $discount = Discount::where('status', 1)->first();

        \Assets::addJs('admin\order.js');
		return view('order.form', compact('data', 'dataCart','fieldOnForm','ordertype','paymenttype', 'productList','cart', 'customer_id', 'discount'));
    }

	public function store(Request $request){
        $values = $request->except('_token', 'save');
        $values['user_id'] = auth()->user()->id;
        $values['status'] = 1;

        $detailOrder = [];
        $cart = Detailcart::where('user_id', Auth()->user()->id)->get();
        foreach($cart as $item){
            $detailOrder[] = new Detailorder([
                'id' => Uuid::uuid4(),
                'user_id' => Auth()->user()->id,
                'product_id' => $item->product_id,
                'price' => $item->price,
                'qty' => $item->qty,
                'status' => 1,
            ]);
        }

        $result = $this->baseStore($request->_method, new Order(), $values, 'Order', 'detailorder', $detailOrder);
        if($result['status'] == 'success'){
            foreach($cart as $item){
                if($item->product->is_unlimited == false){
                    $stock = Stock::where('outlet_id', Auth()->user()->outlet_id)->where('product_id', $item->product_id)->get();

                    $tempQty = $item->qty;
                    foreach($stock as $stockItem){
                        if($tempQty <= $stockItem->qty){
                            $stockItem->qty -= $tempQty;
                            $stockItem->save();
                            break;
                        }else{
                            $tempQty -= $stockItem->qty;
                            $stockItem->qty = 0;
                            $stockItem->save();
                        }
                    }
                }
            }
            Detailcart::where('user_id', Auth()->user()->id)->delete();
        }

		return $this->baseRedirect($request, 'order.index',$result);
    }

	public function show($id){
		$data = Order::findOrFail($id);
		$fieldOnForm = Order::getFieldOnForm();
		return view('order.show', compact('data','fieldOnForm'));
	}
	public function edit($id){
		$data = Order::findOrFail($id);
        $fieldOnForm = Order::getFieldOnForm();
        $ordertype = to_dropdown(getOptionGroup('order_ordertype'), 'key', 'value');
        $paymenttype = to_dropdown(getOptionGroup('order_paymenttype'), 'key', 'value');
		return view('order.form', compact('data','fieldOnForm','ordertype','paymenttype'));
	}
	public function update(Request $request, $id){
		$values = $request->except('_token', '_method');
		$result = $this->baseStore($request->_method, Order::findOrFail($id), $values, 'Order');
		return $this->baseRedirect($request, 'order.index',$result);
	}
	public function destroy(Request $request, $id){
		$result = $this->baseDestroy(Order::findOrFail($id), true);
		return $this->baseRedirect($request, 'order',$result);
	}
	// public function softdelete($id){
	// 	$result = $this->baseStore(Order::findOrFail($id), ['deleted_at' => Carbon::now()]);
	// 	return $this->baseRedirect(new Request(), 'order', $result);
    // }


}
