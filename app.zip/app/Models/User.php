<?php

namespace App\Models;

use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Spatie\Permission\Traits\HasRoles;

class User extends Authenticatable
{
    use Notifiable, HasRoles;

    /**
     * @var string
     */
    protected $keyType = 'string';

    /**
     * @var bool
     */
    public $incrementing = false;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'username','name', 'email', 'password', 'force_change_password',
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
    ];

    public $fieldOnGrid = ['username', 'name', 'email'];

    public function scopeGetFieldOnGrid(){
        return $this->fieldOnGrid;
    }

    public function scopeFetch($query, $request){
        foreach($this->fieldOnGrid as $item){
            if($request->{$item}){
                $query->where($item, 'like', '%'.$request->{$item}.'%');
            }
        }
        return $query->orderBy('name', 'ASC')->paginate(config('app.display_per_page'));
    }

    /**
     * @param $value
     */
    public function setPasswordAttribute($value)
    {
        $this->attributes['password'] = bcrypt($value);
    }

    public function story(){
        return $this->hasMany(Story::class, 'user_id', 'id');
    }


}
